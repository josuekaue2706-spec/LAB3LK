const ideias = [
  "Construa uma casa na copa de uma árvore.",
  "Crie uma base escondida em uma montanha.",
  "Monte uma pequena vila com fazenda.",
  "Construa uma ponte enorme sobre um rio.",
  "Faça uma torre de observação bem alta.",
  "Crie um jardim com lago e iluminação."
];

const botao = document.getElementById("ideiaBtn");
const texto = document.getElementById("ideia");

botao.addEventListener("click", () => {
  const sorteio = Math.floor(Math.random() * ideias.length);
  texto.textContent = ideias[sorteio];
});
